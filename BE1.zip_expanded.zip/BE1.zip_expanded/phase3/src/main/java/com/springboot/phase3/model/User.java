package com.springboot.phase3.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
//    private String username;
    @Column(name = "email_id")
    private String email;
    @Column(name = "password")
    private String password;
    
//    public String getUsername() {
//		return username;
//	}
//	public void setUsername(String username) {
//		this.username = username;
//	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	

    // Constructors, getters, setters, and other methods

    // Getters and setters for id, username, email, and password
    // (You can generate these using your IDE or write them manually)
    
    // Other constructors, getters, setters, and methods as needed
}
