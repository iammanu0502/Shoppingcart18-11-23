package com.springboot.phase3.repo;


import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.springboot.phase3.model.Products;

@Repository
public interface ProductRepository extends JpaRepository<Products, Long>{	
	Optional<Products> findById(Long id);
//	 List<Products> findBygetP_category(String category); // Use field name pCategory
}
