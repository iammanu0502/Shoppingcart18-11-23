package com.springboot.phase3.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.springboot.phase3.model.*;
import com.springboot.phase3.repo.ProductRepository;
import com.springboot.phase3.repo.SignupRepository;
import com.springboot.phase3.repo.OrderRepository;
//import com.springboot.phase3.repo.ProductRepository;
//import com.springboot.phase3.repo.ProductRepository;
//import com.springboot.phase3.repo.ProductsRepository;
//import com.springboot.phase3.repo.ProductsRepository;
import com.springboot.phase3.rnf.ResourceNotFound;
//@CrossOrigin(exposedHeaders="Access-Control-Allow-Origin")
@CrossOrigin(origins = "http://localhost:4200", exposedHeaders="Access-Control-Allow-Origin") /// angular server port
@RestController
@RequestMapping("/api")
public class WebController {

	@Autowired
	private SignupRepository signupRepository;
	@Autowired
	private OrderRepository orderRepository;
	@Autowired
	private ProductRepository productRepository;
	
	
	// ------------------------------methods for signup & user-list----------------------------------//

	// api for posting signup data into db
	@PostMapping("/save-user")
	public Signup create(@RequestBody Signup register_signup) {
		System.out.println("User Registered Sucessfully");
		return signupRepository.save(register_signup);
	}
	
	
	// get all users
	// this is for fetching users
	@GetMapping("/users")				
	public List<Signup> getAllUsers() {
		System.out.println("get all users method is called"); 
		return signupRepository.findAll();
	}

//	 (for login) get user by email rest api

	@GetMapping("/users/email/{email_id}")
	public ResponseEntity<Signup> getUserByEmail_id(@PathVariable String email_id) {
		Signup user = signupRepository.findByEmail_id(email_id);
		System.out.println("login with email");
		return ResponseEntity.ok(user);
	}

	// get user by id rest api

	@GetMapping("/users/{id}")
	public ResponseEntity<Signup> getUserById(@PathVariable Long id) {
		Signup user = signupRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFound("User not exist with id :" + id));
		System.out.println("get by ID");
		return ResponseEntity.ok(user);
	}

//	// update users rest api

	@PutMapping("/users/{id}")
	public ResponseEntity<Signup> createSignup(@PathVariable Long id, @RequestBody Signup userDetails) {
		Signup user = signupRepository.findById(id).orElseThrow();

		user.setUsername(userDetails.getUsername());
		user.setEmail_id(userDetails.getEmail_id());
		user.setPhone_no(userDetails.getPhone_no());
		user.setPassword(userDetails.getPassword());
		user.setConfirm_password(userDetails.getConfirm_password());
		user.setId(userDetails.getId());
		Signup updatedUser = signupRepository.save(user);
		System.out.println("update");
		return ResponseEntity.ok(updatedUser);
	}

	// delete user rest api

	@DeleteMapping("/users/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable Long id) {
		Signup user = signupRepository.findById(id).orElseThrow();

		signupRepository.delete(user);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}

	// ------------------------------methods for order & order-list----------------------------------//

	@PostMapping("/placeorder")
	public Orders orders(@RequestBody Orders create_orders) {
		System.out.println("User Order created");
		return orderRepository.save(create_orders);
	}


	
	
//	// get all orders

	@GetMapping("/orders")
	public List<Orders> getAllOrders() {
		System.out.println("get all orders method is called");
		return orderRepository.findAll();
	}
//
//	// get orders by id rest api

	@GetMapping("/orders/{id}")
	public ResponseEntity<Orders> getOrderById(@PathVariable Long id) {
		Orders order = orderRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFound("Order not exist with id :" + id));
		return ResponseEntity.ok(order);
	}
//
//	// update orders rest api
//
	@PutMapping("/orders/{id}")
	public ResponseEntity<Orders> UpdateOrder(@PathVariable Long id, @RequestBody Orders orderDetails) {
		Orders order = orderRepository.findById(id).orElseThrow();

		order.setProductName(orderDetails.getProductName());
		order.setUserName(orderDetails.getUserName());
		order.setEmailId(orderDetails.getEmailId());
		order.setPhoneNumber(orderDetails.getPhoneNumber());
		order.setAddress(orderDetails.getAddress());
		order.setOrderDate(orderDetails.getOrderDate());
		order.setState(orderDetails.getState());
		order.setCity(orderDetails.getCity());
		order.setZipCode(orderDetails.getZipCode());
		order.setPayment_method(orderDetails.getPayment_method());
		order.setStatus(orderDetails.getStatus());
		
		Orders updatedOrder = orderRepository.save(order);
		return ResponseEntity.ok(updatedOrder);
	}
//
//	// delete orders rest api
//
	@DeleteMapping("/orders/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteOrder(@PathVariable Long id) {
		Orders order = orderRepository.findById(id).orElseThrow();

		orderRepository.delete(order);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
//
////	 ------------------------------methods for product & product-list----------------------------------//
//
	// api for posting products data into db
	@PostMapping("/products")
	public Products createProduct(@RequestBody Products create_product) {
		return productRepository.save(create_product);
	}
	
	// get all products

		@GetMapping("/products")
		public List<Products> getAllProducts() {
			System.out.println("get all products method is called");
			return productRepository.findAll();
		}
		




	
	@DeleteMapping("/products/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteProduct(@PathVariable Long id) {
			Products product = productRepository.findById(id).orElseThrow();

			productRepository.delete(product);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}
		
		
	// update orders rest api

		@PutMapping("/products/{id}")
		public ResponseEntity<Products> updateProduct(@PathVariable Long id, @RequestBody Products productDetails) {
			Products product = productRepository.findById(id).orElseThrow();

			product.setP_name(productDetails.getP_name());
			product.setP_description(productDetails.getP_description());
			product.setP_category(productDetails.getP_category());
			product.setP_seller(productDetails.getP_seller());
			product.setP_price(productDetails.getP_price());
			product.setImage(productDetails.getImage());
			

			Products updatedProduct = productRepository.save(product);
			System.out.println("product update is called");
			return ResponseEntity.ok(updatedProduct);
		}
		
		// get product by id rest api

		@GetMapping("/products/{id}")
		public ResponseEntity<Products> getProductById(@PathVariable Long id) {
			Products product = productRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFound("Order not exist with id :" + id));
			System.out.println("get product by id is called");
			return ResponseEntity.ok(product);
		}
		
//		@GetMapping("/category/{category}")
//	    public List<Products> getProductsByCategory(@PathVariable String category) {
//	        List<Products> products = productRepository.findBygetP_category(category);
//
//	        if (products.isEmpty()) {
//	            // Handle the case where no products were found for the specified category
//	            // You can return an empty list or an appropriate HTTP response.
//	        }
//
//	        return products;
//	    }
		
		

}