package com.springboot.phase3.config;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration

@EnableJpaRepositories(basePackages = "com.springboot.phase3.repo")
public class JpaConfig {

}