export class Updateproduct{
  p_name:string;
  p_id:number;
  p_category:string;
  p_seller:string;
  p_description:string;
  p_price:string;
  image:string;
  }

