export class Adminpanel{
  email_id: string ;
  password: string ;
}
