export class Prod{
  id: number;
  p_name:string;
  p_category:string;
  p_seller:string;
  p_description:string;
  p_price:string;
  image:string;
  }

