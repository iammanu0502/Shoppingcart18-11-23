export class LoginFields {
  email_id: string;
  password: string;
}
