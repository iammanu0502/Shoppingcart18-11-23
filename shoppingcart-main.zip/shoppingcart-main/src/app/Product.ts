export class Product {
  id: number;
  productName: string;
  userName: string;
  emailId: string;
  phoneNumber: number;
  address:string;
  orderDate:Date;
  state: string;
  city: string;
  zipCode:number;

}
