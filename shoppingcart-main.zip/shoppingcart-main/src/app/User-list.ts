export class Userlist {
  id: number ;
  email_id: string ;
  username: string ;
  phone_no: string ;
  password: string ;
  confirm_password : string;

}
