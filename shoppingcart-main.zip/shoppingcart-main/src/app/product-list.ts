export class Productlist {
  id: number;
  p_name: string;
  p_description: string;
  p_seller: string;
  p_category: string;
  p_price:string;
}
